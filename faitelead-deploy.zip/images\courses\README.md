# Pasta para Imagens de Cursos

Coloque as imagens dos seus cursos aqui!

## Como usar:

1. Cole suas imagens nesta pasta
2. Renomeie para nomes simples (ex: `teologia-basica.jpg`)
3. Use o script do Console para adicionar ao sistema

## Formato recomendado:
- **Tipo:** JPG ou PNG
- **Tamanho:** 500KB - 2MB
- **Resolução:** 800x450px ou similar (16:9)

## Exemplo de nomes:
- teologia-basica.jpg
- teologia-sistematica.jpg
- bibliologia.jpg
- evangelismo.jpg
